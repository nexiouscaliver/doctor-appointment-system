import sqlite3

def create_appointments_table():
    # Connect to the SQLite database
    conn = sqlite3.connect('doctor_appointment_system.db')
    
    # Create a cursor object to execute SQL commands
    cur = conn.cursor()
    
    # Define the SQL command to create the Appoint table
    create_table_query = """
    CREATE TABLE IF NOT EXISTS Appoint (
        AppID INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id INTEGER,
        patient_name TEXT NOT NULL,
        Appoint_date TEXT NOT NULL,
        Appoint_time TEXT NOT NULL,
        status TEXT NOT NULL,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id)
    );
    """
    
    # Execute the command
    cur.execute(create_table_query)
    
    # Commit the changes and close the connection
    conn.commit()
    conn.close()
    print("Appointments table created successfully.")

# Run the function to create the table
create_appointments_table()

import sqlite3

# Connect to SQLite database
conn = sqlite3.connect('doctordb.db')

# Create a cursor object to execute SQL commands
cur = conn.cursor()

# Define the SQL command to create the doctors table
create_table_sql = '''
    CREATE TABLE IF NOT EXISTS doctors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        specialization TEXT NOT NULL
    )
'''

# Execute the SQL command to create the table
cur.execute(create_table_sql)

# Commit the transaction and close the connection
conn.commit()
conn.close()

print("Doctors table created successfully")

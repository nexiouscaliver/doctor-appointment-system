import os
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    # Print current working directory
    print("Current working directory:", os.getcwd())

    # Print contents of the template folder
    template_dir = os.path.join(os.getcwd(), 'templates')
    print("Contents of the 'templates' directory:", os.listdir(template_dir))

    return render_template('docLog.html')

if __name__ == '__main__':
    app.run(debug=True)

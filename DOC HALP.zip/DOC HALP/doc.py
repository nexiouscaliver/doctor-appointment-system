from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DATABASE = 'doctor_appointment_system.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def check_existing_appointment(doctor_id, appoint_date, appoint_time):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM Appoint WHERE doctor_id = ? AND Appoint_date = ? AND Appoint_time = ?", (doctor_id, appoint_date, appoint_time))
    appointment = cur.fetchone()
    conn.close()
    return appointment is not None

@app.route('/')
def home():
    return render_template('docBase.html')

@app.route('/docReg', methods=['GET', 'POST'])
def docReg():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        specialization = request.form['specialization']
        conn = get_db()
        cur = conn.cursor()
        cur.execute("INSERT INTO doctors (name, email, password, specialization) VALUES (?, ?, ?, ?)", (name, email, password, specialization))
        conn.commit()
        conn.close()
        return redirect(url_for('home'))
    return render_template('docReg.html')

@app.route('/docLog', methods=['GET', 'POST'])
def docLog():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM doctors WHERE email = ? AND password = ?", (email, password))
        doctor = cur.fetchone()
        conn.close()
        if doctor:
            session['doctor_id'] = doctor['id']
            session['doctor_name'] = doctor['name']
            return redirect(url_for('docDash'))
        else:
            return "Invalid credentials"
    return render_template('docLog.html')

@app.route('/docDash')
def docDash():
    if 'doctor_id' in session:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM Appoint WHERE doctor_id = ?", (session['doctor_id'],))
        appointments = cur.fetchall()
        conn.close()
        return render_template('docDash.html', appointments=appointments)
    return redirect(url_for('docLog'))

@app.route('/docApt', methods=['GET', 'POST'])
def docApt():
    if 'doctor_id' in session:
        if request.method == 'POST':
            patient_name = request.form['patient_name']
            appoint_date = request.form['appoint_date']
            appoint_time = request.form['appoint_time']
            doctor_id = session['doctor_id']
            
            if check_existing_appointment(doctor_id, appoint_date, appoint_time):
                return "Appointment slot already taken"
            
            conn = get_db()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO Appoint (doctor_id, patient_name, Appoint_date, Appoint_time, status)
                VALUES (?, ?, ?, ?, ?)
            """, (doctor_id, patient_name, appoint_date, appoint_time, 'scheduled'))
            conn.commit()
            conn.close()
            return redirect(url_for('docDash'))
        
        return render_template('docApt.html')
    return redirect(url_for('docLog'))

@app.route('/docMan/<int:id>', methods=['GET', 'POST'])
def docMan(id):
    if 'doctor_id' in session:
        conn = get_db()
        cur = conn.cursor()
        if request.method == 'POST':
            status = request.form['status']
            if status == 'confirm':
                cur.execute("UPDATE Appoint SET status = 'confirmed' WHERE AppID = ?", (id,))
            elif status == 'reschedule':
                new_date = request.form['new_date']
                new_time = request.form['new_time']
                cur.execute("UPDATE Appoint SET Appoint_date = ?, Appoint_time = ? WHERE AppID = ?", (new_date, new_time, id))
            elif status == 'cancel':
                cur.execute("DELETE FROM Appoint WHERE AppID = ?", (id,))
            conn.commit()
            conn.close()
            return redirect(url_for('docDash'))
        cur.execute("SELECT * FROM Appoint WHERE AppID = ?", (id,))
        appointment = cur.fetchone()
        conn.close()
        return render_template('docMan.html', appointment=appointment)
    return redirect(url_for('docLog'))

@app.route('/logout')
def logout():
    session.pop('doctor_id', None)
    session.pop('doctor_name', None)
    return redirect(url_for('docLog'))

if __name__ == '__main__':
    app.run(debug=True)
